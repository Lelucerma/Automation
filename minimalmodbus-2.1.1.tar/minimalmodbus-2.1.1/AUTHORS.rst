=======
Credits
=======

Development Lead
----------------

* Jonas Berg https://github.com/pyhys

Contributors
------------

Significant contributions by:

* Aaron LaLonde
* Andres Ulloa
* Angelo Compagnucci
* Asier Abalos
* Austin Stover
* Benedikt Moneke (Github user: bmoneke)
* Dino
* Dominik Socha
* Edgar Bonet
* Edwin van den Oetelaar
* Github user: draput
* Github user: gnbl
* Github user: mrrs6
* Github user: noafterglow
* Jan Breuer (Github user: j123b567)
* Luca Di Gregorio
* Matthias Bolte
* Martijn de Gouw (Github user: martijndegouw)
* Michael Penza
* Peter
* Russ Garrett
* Yurij Z (Github user: zyura)

